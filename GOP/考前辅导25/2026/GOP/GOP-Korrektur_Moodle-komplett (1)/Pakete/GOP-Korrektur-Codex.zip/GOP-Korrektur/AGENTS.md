# GOP-Korrektur-Arbeitsordner

Nutze den Skill `gop-korrektur`, sobald eine PDF-Abgabe zu einem der enthaltenen GOP-Übungsblätter korrigiert oder eine bestehende Bewertung erläutert werden soll.

Lege studentische Abgaben unter `Abgaben/` und fertige Bewertungsdateien sowie korrigierte PDFs unter `Ergebnisse/` ab. Überschreibe niemals die Originalabgabe.

