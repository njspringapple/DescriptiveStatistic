# GOP-Korrektur-Arbeitsordner

Verwende für Korrekturen den Skill `/gop-korrektur`. Studentische Abgaben liegen unter `Abgaben/`; Ergebnisse gehören nach `Ergebnisse/`. Die Originalabgabe darf nicht überschrieben werden.

